// this is the cpp file for computing the posterior prediction of a given feature matrix
